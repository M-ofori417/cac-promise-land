-- -------------------------------
-- Drop tables if exist
-- -------------------------------
DROP TABLE IF EXISTS results CASCADE;
DROP TABLE IF EXISTS questions CASCADE;
DROP TABLE IF EXISTS quizzes CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- -------------------------------
-- Create Tables
-- -------------------------------

-- Users
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE
);

-- Quizzes
CREATE TABLE quizzes (
    quiz_id SERIAL PRIMARY KEY,
    title VARCHAR(100),
    subject VARCHAR(50)
);

-- Questions
CREATE TABLE questions (
    question_id SERIAL PRIMARY KEY,
    quiz_id INT REFERENCES quizzes(quiz_id),
    question_text TEXT,
    correct_answer VARCHAR(100)
);

-- Results
CREATE TABLE results (
    result_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id),
    quiz_id INT REFERENCES quizzes(quiz_id),
    score NUMERIC(5,2),
    taken_date DATE DEFAULT CURRENT_DATE
);

-- -------------------------------
-- Insert Sample Data
-- -------------------------------
INSERT INTO users (first_name,last_name,email) VALUES
('Samuel','Oppong','sammy@example.com'),
('Linda','Adjei','linda@example.com');

INSERT INTO quizzes (title,subject) VALUES
('Math Basics','Mathematics'),
('English Grammar','English');

INSERT INTO questions (quiz_id,question_text,correct_answer) VALUES
(1,'2 + 2 = ?','4'),
(1,'5 - 3 = ?','2'),
(2,'Choose the correct verb: She ___ to school.','goes');

INSERT INTO results (user_id,quiz_id,score,taken_date) VALUES
(1,1,95,'2025-08-20'),
(2,2,88,'2025-08-21');

-- -------------------------------
-- Select Queries
-- -------------------------------
-- All quizzes
SELECT * FROM quizzes;

-- Questions for Math Basics
SELECT q.question_text, q.correct_answer
FROM questions q
JOIN quizzes z ON q.quiz_id = z.quiz_id
WHERE z.title = 'Math Basics';

-- Results with user and quiz info
SELECT r.result_id, u.first_name, u.last_name, q.title, r.score, r.taken_date
FROM results r
JOIN users u ON r.user_id = u.user_id
JOIN quizzes q ON r.quiz_id = q.quiz_id;

-- -------------------------------
-- Update & Delete
-- -------------------------------
-- Update score for a user
UPDATE results SET score = 97 WHERE result_id = 1;

-- Delete a question
DELETE FROM questions WHERE question_id = 3;

-- -------------------------------
-- Views & Index
-- -------------------------------
CREATE VIEW user_quiz_summary AS
SELECT u.first_name, u.last_name, q.title AS quiz_title, r.score, r.taken_date
FROM results r
JOIN users u ON r.user_id = u.user_id
JOIN quizzes q ON r.quiz_id = q.quiz_id;

CREATE INDEX idx_quiz_title ON quizzes(title);

-- -------------------------------
-- Aggregation
-- -------------------------------
-- Average score per quiz
SELECT q.title, AVG(r.score) AS avg_score
FROM quizzes q
JOIN results r ON q.quiz_id = r.quiz_id
GROUP BY q.title;

-- Total quizzes taken per user
SELECT u.first_name, u.last_name, COUNT(r.result_id) AS total_quizzes
FROM users u
LEFT JOIN results r ON u.user_id = r.user_id
GROUP BY u.first_name, u.last_name;
