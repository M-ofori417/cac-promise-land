-- -------------------------------
-- Drop tables if exist
-- -------------------------------
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS menus CASCADE;
DROP TABLE IF EXISTS restaurants CASCADE;
DROP TABLE IF EXISTS customers CASCADE;

-- -------------------------------
-- Create Tables
-- -------------------------------

-- Customers
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    address VARCHAR(150)
);

-- Restaurants
CREATE TABLE restaurants (
    restaurant_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    location VARCHAR(100)
);

-- Menus
CREATE TABLE menus (
    menu_id SERIAL PRIMARY KEY,
    restaurant_id INT REFERENCES restaurants(restaurant_id),
    food_name VARCHAR(100),
    price NUMERIC(10,2)
);

-- Orders
CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(customer_id),
    menu_id INT REFERENCES menus(menu_id),
    quantity INT,
    order_date DATE DEFAULT CURRENT_DATE
);

-- -------------------------------
-- Insert Sample Data
-- -------------------------------
INSERT INTO customers (first_name,last_name,email,phone,address) VALUES
('Samuel','Oppong','sammy@example.com','0244000000','Kumasi'),
('Linda','Adjei','linda@example.com','0244111111','Accra');

INSERT INTO restaurants (name,location) VALUES
('Pizza Palace','Kumasi'),
('Burger King','Accra');

INSERT INTO menus (restaurant_id,food_name,price) VALUES
(1,'Margherita Pizza',10.50),
(1,'Pepperoni Pizza',12.00),
(2,'Cheeseburger',8.00),
(2,'Fries',3.50);

INSERT INTO orders (customer_id,menu_id,quantity,order_date) VALUES
(1,1,2,'2025-08-20'),
(1,4,1,'2025-08-20'),
(2,3,1,'2025-08-21');

-- -------------------------------
-- Select Queries
-- -------------------------------
-- All orders with customer and food info
SELECT o.order_id, c.first_name, c.last_name, r.name AS restaurant, m.food_name, o.quantity, m.price, o.order_date
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN menus m ON o.menu_id = m.menu_id
JOIN restaurants r ON m.restaurant_id = r.restaurant_id;

-- Orders per customer
SELECT c.first_name, c.last_name, COUNT(o.order_id) AS total_orders
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.first_name, c.last_name;

-- -------------------------------
-- Update & Delete
-- -------------------------------
-- Update quantity
UPDATE orders SET quantity = 3 WHERE order_id = 1;

-- Delete an order
DELETE FROM orders WHERE order_id = 3;

-- -------------------------------
-- Views & Index
-- -------------------------------
CREATE VIEW order_summary AS
SELECT c.first_name, c.last_name, r.name AS restaurant, m.food_name, o.quantity, m.price, o.order_date
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN menus m ON o.menu_id = m.menu_id
JOIN restaurants r ON m.restaurant_id = r.restaurant_id;

CREATE INDEX idx_food_name ON menus(food_name);

-- -------------------------------
-- Aggregation
-- -------------------------------
-- Total spent per customer
SELECT c.first_name, c.last_name, SUM(o.quantity * m.price) AS total_spent
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
JOIN menus m ON o.menu_id = m.menu_id
GROUP BY c.first_name, c.last_name;

-- Total orders per restaurant
SELECT r.name, COUNT(o.order_id) AS total_orders
FROM restaurants r
JOIN menus m ON r.restaurant_id = m.restaurant_id
JOIN orders o ON m.menu_id = o.menu_id
GROUP BY r.name;
