-- -------------------------------
-- Drop tables if exist
-- -------------------------------
DROP TABLE IF EXISTS rentals CASCADE;
DROP TABLE IF EXISTS movies CASCADE;
DROP TABLE IF EXISTS customers CASCADE;
DROP TABLE IF EXISTS staff CASCADE;

-- -------------------------------
-- Create Tables
-- -------------------------------

-- Staff
CREATE TABLE staff (
    staff_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE
);

-- Customers
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15)
);

-- Movies
CREATE TABLE movies (
    movie_id SERIAL PRIMARY KEY,
    title VARCHAR(100),
    genre VARCHAR(50),
    release_year INT,
    stock INT DEFAULT 1
);

-- Rentals
CREATE TABLE rentals (
    rental_id SERIAL PRIMARY KEY,
    movie_id INT REFERENCES movies(movie_id),
    customer_id INT REFERENCES customers(customer_id),
    rental_date DATE DEFAULT CURRENT_DATE,
    return_date DATE
);

-- -------------------------------
-- Insert Sample Data
-- -------------------------------
INSERT INTO staff (first_name,last_name,email) VALUES
('John','Doe','john@movierent.com'),
('Jane','Smith','jane@movierent.com');

INSERT INTO customers (first_name,last_name,email,phone) VALUES
('Samuel','Oppong','sammy@example.com','0244000000'),
('Linda','Adjei','linda@example.com','0244111111');

INSERT INTO movies (title,genre,release_year,stock) VALUES
('Inception','Sci-Fi',2010,5),
('Titanic','Romance',1997,3),
('Avengers','Action',2019,4);

INSERT INTO rentals (movie_id,customer_id,rental_date,return_date) VALUES
(1,1,'2025-08-20','2025-08-27'),
(2,2,'2025-08-21',NULL);

-- -------------------------------
-- Select Queries
-- -------------------------------
-- All movies
SELECT * FROM movies;

-- Rentals with customer and movie info
SELECT r.rental_id, c.first_name, c.last_name, m.title, r.rental_date, r.return_date
FROM rentals r
JOIN customers c ON r.customer_id = c.customer_id
JOIN movies m ON r.movie_id = m.movie_id;

-- -------------------------------
-- Update & Delete
-- -------------------------------
-- Update stock after rental
UPDATE movies SET stock = stock - 1 WHERE movie_id = 1;

-- Delete rental record
DELETE FROM rentals WHERE rental_id = 2;

-- -------------------------------
-- Views & Index
-- -------------------------------
CREATE VIEW rental_summary AS
SELECT c.first_name, c.last_name, m.title, r.rental_date, r.return_date
FROM rentals r
JOIN customers c ON r.customer_id = c.customer_id
JOIN movies m ON r.movie_id = m.movie_id;

CREATE INDEX idx_movie_title ON movies(title);

-- -------------------------------
-- Aggregation
-- -------------------------------
-- Total rentals per movie
SELECT m.title, COUNT(r.rental_id) AS total_rentals
FROM movies m
LEFT JOIN rentals r ON m.movie_id = r.movie_id
GROUP BY m.title;
