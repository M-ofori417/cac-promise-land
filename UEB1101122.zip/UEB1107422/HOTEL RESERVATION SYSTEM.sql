-- -------------------------------
-- Drop tables if exist
-- -------------------------------
DROP TABLE IF EXISTS bookings CASCADE;
DROP TABLE IF EXISTS rooms CASCADE;
DROP TABLE IF EXISTS guests CASCADE;
DROP TABLE IF EXISTS staff CASCADE;

-- -------------------------------
-- Create Tables
-- -------------------------------

-- Staff
CREATE TABLE staff (
    staff_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE
);

-- Guests
CREATE TABLE guests (
    guest_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15)
);

-- Rooms
CREATE TABLE rooms (
    room_id SERIAL PRIMARY KEY,
    room_number VARCHAR(10) UNIQUE NOT NULL,
    room_type VARCHAR(20),
    price NUMERIC(10,2),
    status VARCHAR(20) DEFAULT 'Available'
);

-- Bookings
CREATE TABLE bookings (
    booking_id SERIAL PRIMARY KEY,
    guest_id INT REFERENCES guests(guest_id),
    room_id INT REFERENCES rooms(room_id),
    check_in DATE,
    check_out DATE
);

-- -------------------------------
-- Insert Sample Data
-- -------------------------------
INSERT INTO staff (first_name,last_name,email) VALUES
('John','Doe','john@hotel.com'),
('Mary','Smith','mary@hotel.com');

INSERT INTO guests (first_name,last_name,email,phone) VALUES
('Samuel','Oppong','sammy@example.com','0244000000'),
('Linda','Adjei','linda@example.com','0244111111');

INSERT INTO rooms (room_number,room_type,price,status) VALUES
('101','Single',100,'Available'),
('102','Double',150,'Available'),
('103','Suite',250,'Available');

INSERT INTO bookings (guest_id,room_id,check_in,check_out) VALUES
(1,1,'2025-08-20','2025-08-25'),
(2,2,'2025-08-21','2025-08-26');

-- Update room status after booking
UPDATE rooms
SET status = 'Booked'
WHERE room_id IN (1,2);

-- -------------------------------
-- Select Queries
-- -------------------------------
-- All rooms
SELECT * FROM rooms;

-- Bookings with guest info
SELECT b.booking_id, g.first_name, g.last_name, r.room_number, r.room_type, b.check_in, b.check_out
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id;

-- -------------------------------
-- Update & Delete
-- -------------------------------
-- Checkout guest from room 101
UPDATE rooms SET status = 'Available' WHERE room_number = '101';
UPDATE bookings SET check_out = CURRENT_DATE WHERE booking_id = 1;

-- Delete a booking
DELETE FROM bookings WHERE booking_id = 2;

-- -------------------------------
-- Views & Index
-- -------------------------------
CREATE VIEW booking_summary AS
SELECT g.first_name, g.last_name, r.room_number, r.room_type, b.check_in, b.check_out
FROM bookings b
JOIN guests g ON b.guest_id = g.guest_id
JOIN rooms r ON b.room_id = r.room_id;

CREATE INDEX idx_room_number ON rooms(room_number);

-- -------------------------------
-- Aggregation
-- -------------------------------
-- Total bookings per room type
SELECT room_type, COUNT(*) AS total_bookings
FROM rooms r
JOIN bookings b ON r.room_id = b.room_id
GROUP BY room_type;

-- Total revenue per room type
SELECT room_type, SUM(price) AS total_revenue
FROM rooms r
JOIN bookings b ON r.room_id = b.room_id
GROUP BY room_type;
