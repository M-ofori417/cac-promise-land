-- -------------------------------
-- Drop tables if exist
-- -------------------------------
DROP TABLE IF EXISTS attendance CASCADE;
DROP TABLE IF EXISTS classes CASCADE;
DROP TABLE IF EXISTS trainers CASCADE;
DROP TABLE IF EXISTS members CASCADE;

-- -------------------------------
-- Create Tables
-- -------------------------------

-- Members
CREATE TABLE members (
    member_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    membership_start DATE DEFAULT CURRENT_DATE
);

-- Trainers
CREATE TABLE trainers (
    trainer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    specialty VARCHAR(50)
);

-- Classes
CREATE TABLE classes (
    class_id SERIAL PRIMARY KEY,
    trainer_id INT REFERENCES trainers(trainer_id),
    class_name VARCHAR(50),
    schedule TIME
);

-- Attendance
CREATE TABLE attendance (
    attendance_id SERIAL PRIMARY KEY,
    member_id INT REFERENCES members(member_id),
    class_id INT REFERENCES classes(class_id),
    attendance_date DATE DEFAULT CURRENT_DATE
);

-- -------------------------------
-- Insert Sample Data
-- -------------------------------
INSERT INTO members (first_name,last_name,email,phone) VALUES
('Samuel','Oppong','sammy@example.com','0244000000'),
('Linda','Adjei','linda@example.com','0244111111');

INSERT INTO trainers (first_name,last_name,specialty) VALUES
('John','Doe','Weight Training'),
('Mary','Smith','Yoga');

INSERT INTO classes (trainer_id,class_name,schedule) VALUES
(1,'Strength Training','08:00'),
(2,'Morning Yoga','07:00');

INSERT INTO attendance (member_id,class_id,attendance_date) VALUES
(1,1,'2025-08-20'),
(2,2,'2025-08-21');

-- -------------------------------
-- Select Queries
-- -------------------------------
-- All members
SELECT * FROM members;

-- Class attendance with member and trainer info
SELECT a.attendance_id, m.first_name AS member_first, m.last_name AS member_last,
       c.class_name, t.first_name AS trainer_first, t.last_name AS trainer_last, a.attendance_date
FROM attendance a
JOIN members m ON a.member_id = m.member_id
JOIN classes c ON a.class_id = c.class_id
JOIN trainers t ON c.trainer_id = t.trainer_id;

-- -------------------------------
-- Update & Delete
-- -------------------------------
-- Update membership start date
UPDATE members SET membership_start = '2025-08-01' WHERE member_id = 1;

-- Delete an attendance record
DELETE FROM attendance WHERE attendance_id = 2;

-- -------------------------------
-- Views & Index
-- -------------------------------
CREATE VIEW attendance_summary AS
SELECT m.first_name AS member_first, m.last_name AS member_last,
       c.class_name, t.first_name AS trainer_first, t.last_name AS trainer_last, a.attendance_date
FROM attendance a
JOIN members m ON a.member_id = m.member_id
JOIN classes c ON a.class_id = c.class_id
JOIN trainers t ON c.trainer_id = t.trainer_id;

CREATE INDEX idx_class_name ON classes(class_name);

-- -------------------------------
-- Aggregation
-- -------------------------------
-- Total classes attended per member
SELECT m.first_name, m.last_name, COUNT(a.attendance_id) AS total_classes
FROM members m
LEFT JOIN attendance a ON m.member_id = a.member_id
GROUP BY m.first_name, m.last_name;

-- Total members per trainer
SELECT t.first_name, t.last_name, COUNT(a.attendance_id) AS total_members
FROM trainers t
JOIN classes c ON t.trainer_id = c.trainer_id
LEFT JOIN attendance a ON c.class_id = a.class_id
GROUP BY t.first_name, t.last_name;
